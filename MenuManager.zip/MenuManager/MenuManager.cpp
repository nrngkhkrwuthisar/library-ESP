#include "MenuManager.h"

MenuManager::MenuManager(LiquidCrystal_I2C* lcd) {
    this->lcd = lcd;
    menuItems = nullptr;
    menuCount = 0;
    menuIndex = 0;
}

MenuManager::~MenuManager() {
    delete[] menuItems; 
}

void MenuManager::add(const String& menuName) {
    String* temp = new String[menuCount + 1];
    for (int i = 0; i < menuCount; i++) {
        temp[i] = menuItems[i];
    }
    temp[menuCount] = menuName;
    delete[] menuItems;
    menuItems = temp;
    menuCount++;
}

void MenuManager::displayMenu() {
    lcd->clear();
    if (menuCount > 0 && menuIndex < menuCount) {
        lcd->setCursor(0, 0); 
        lcd->print(menuItems[menuIndex]);
    }
}

void MenuManager::handleInput(int btnNext, int btnSelect) {
    if (digitalRead(btnNext) == LOW) {
        delay(300); 
        menuIndex = (menuIndex + 1) % menuCount;
        displayMenu();
    }

    if (digitalRead(btnSelect) == LOW) {
        delay(300); 
        lcd->clear();
        lcd->setCursor(0, 0);
        lcd->print(menuItems[menuIndex] + " Selected");
        delay(2000);
        displayMenu();
    }
}

String MenuManager::getSelectedMenu() {
    return (menuIndex < menuCount) ? menuItems[menuIndex] : "";
}
