#ifndef MENU_MANAGER_H
#define MENU_MANAGER_H

#include <Arduino.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h> 

class MenuManager {
private:
    String* menuItems; 
    int menuCount;
    int menuIndex;
    LiquidCrystal_I2C* lcd;

public:
    MenuManager(LiquidCrystal_I2C* lcd); 
    ~MenuManager(); 

    void add(const String& menuName); 
    void displayMenu(); 
    void handleInput(int btnNext, int btnSelect); 

    String getSelectedMenu(); 
};

#endif
